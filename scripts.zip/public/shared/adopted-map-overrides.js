(function (root, factory) {
  const data = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = data;
  if (root) root.ADOPTED_MAP_OVERRIDES = data;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  return Object.freeze({
    "version": 72,
    "maps": {
      "prototypeIsland": {
        "name": "Prototype Island",
        "dimensions": {
          "width": 760,
          "height": 560
        },
        "playerSpawns": [
          {
            "id": "center",
            "x": 427,
            "y": 368
          },
          {
            "id": "eastBridge",
            "x": 564,
            "y": 280
          },
          {
            "id": "westBridge",
            "x": 136,
            "y": 280
          }
        ],
        "portals": [
          {
            "id": "prototypeIsland:portal:east",
            "x": 568,
            "y": 254,
            "width": 12,
            "height": 52,
            "targetMapId": "spawn",
            "targetSpawnId": "westPrototype"
          },
          {
            "id": "prototypeIsland:portal:west",
            "x": 120,
            "y": 254,
            "width": 12,
            "height": 52,
            "targetMapId": "prototypeIslandWest",
            "targetSpawnId": "eastBridge"
          }
        ],
        "environment": {
          "trees": [
            {
              "id": "prototypeIsland:tree:1",
              "x": 216,
              "y": 139,
              "phase": 0.42,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:2",
              "x": 209,
              "y": 425,
              "phase": 1.15,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:3",
              "x": 245,
              "y": 132,
              "phase": 1.88,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:4",
              "x": 228,
              "y": 420,
              "phase": 2.61,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:5",
              "x": 272,
              "y": 139,
              "phase": 3.34,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:6",
              "x": 250,
              "y": 425,
              "phase": 4.07,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:7",
              "x": 298,
              "y": 133,
              "phase": 4.800000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:8",
              "x": 273,
              "y": 421,
              "phase": 5.530000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:9",
              "x": 322,
              "y": 138,
              "phase": 6.260000000000002,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:10",
              "x": 293,
              "y": 425,
              "phase": 6.990000000000002,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:13",
              "x": 376,
              "y": 137,
              "phase": 9.180000000000003,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:14",
              "x": 452,
              "y": 421,
              "phase": 9.910000000000004,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:15",
              "x": 399,
              "y": 131,
              "phase": 10.640000000000004,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:17",
              "x": 464,
              "y": 154,
              "phase": 12.100000000000005,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:18",
              "x": 487,
              "y": 423,
              "phase": 12.830000000000005,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:19",
              "x": 212,
              "y": 235,
              "phase": 13.560000000000006,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:20",
              "x": 219,
              "y": 404,
              "phase": 14.290000000000006,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:21",
              "x": 488,
              "y": 227,
              "phase": 15.020000000000007,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:22",
              "x": 208,
              "y": 329,
              "phase": 15.750000000000007,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:23",
              "x": 485,
              "y": 247,
              "phase": 16.480000000000008,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:24",
              "x": 217,
              "y": 348,
              "phase": 17.210000000000008,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:25",
              "x": 208,
              "y": 257,
              "phase": 17.94000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:26",
              "x": 209,
              "y": 365,
              "phase": 18.67000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:27",
              "x": 489,
              "y": 264,
              "phase": 19.40000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:28",
              "x": 377,
              "y": 424,
              "phase": 20.13000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:29",
              "x": 467,
              "y": 132,
              "phase": 20.86000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:30",
              "x": 481,
              "y": 323,
              "phase": 21.59000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:31",
              "x": 486,
              "y": 136,
              "phase": 22.32000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:33",
              "x": 419,
              "y": 134,
              "phase": 23.780000000000012,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:34",
              "x": 414,
              "y": 428,
              "phase": 24.510000000000012,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:35",
              "x": 205,
              "y": 159,
              "phase": 25.240000000000013,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:36",
              "x": 482,
              "y": 157,
              "phase": 25.970000000000013,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:37",
              "x": 211,
              "y": 184,
              "phase": 26.700000000000014,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:38",
              "x": 485,
              "y": 178,
              "phase": 27.430000000000014,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:39",
              "x": 207,
              "y": 206,
              "phase": 28.160000000000014,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:40",
              "x": 466,
              "y": 216,
              "phase": 28.890000000000015,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:42",
              "x": 487,
              "y": 382,
              "phase": 30.350000000000016,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:43",
              "x": 225,
              "y": 315,
              "phase": 31.080000000000016,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:44",
              "x": 477,
              "y": 403,
              "phase": 31.810000000000016,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:45",
              "x": 209,
              "y": 392,
              "phase": 32.54000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:46",
              "x": 392,
              "y": 410,
              "phase": 33.27000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:50",
              "x": 221,
              "y": 157,
              "phase": 36.19,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:51",
              "x": 256,
              "y": 147,
              "phase": 36.92,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:52",
              "x": 286,
              "y": 148,
              "phase": 37.65,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:53",
              "x": 310,
              "y": 149,
              "phase": 38.38,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:56",
              "x": 390,
              "y": 152,
              "phase": 40.57,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:57",
              "x": 411,
              "y": 148,
              "phase": 41.3,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:58",
              "x": 440,
              "y": 139,
              "phase": 42.03,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:59",
              "x": 460,
              "y": 151,
              "phase": 42.76,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:60",
              "x": 229,
              "y": 177,
              "phase": 43.49,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:11",
              "x": 400,
              "y": 320,
              "phase": 42.03,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:54",
              "x": 428,
              "y": 403,
              "phase": 42.76,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:47",
              "x": 483,
              "y": 355,
              "phase": 41.3,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:48",
              "x": 290,
              "y": 206,
              "phase": 42.03,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:49",
              "x": 308,
              "y": 325,
              "phase": 42.76,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:55",
              "x": 373,
              "y": 342,
              "phase": 43.49,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:61",
              "x": 325,
              "y": 279,
              "phase": 44.22,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIsland:tree:62",
              "x": 328,
              "y": 206,
              "phase": 44.95,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:63",
              "x": 343,
              "y": 232,
              "phase": 45.68,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:64",
              "x": 368,
              "y": 207,
              "phase": 46.41,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:66",
              "x": 377,
              "y": 379,
              "phase": 47.87,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:67",
              "x": 306,
              "y": 297,
              "phase": 48.6,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:68",
              "x": 264,
              "y": 295,
              "phase": 49.33,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:69",
              "x": 280,
              "y": 360,
              "phase": 50.06,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:71",
              "x": 250,
              "y": 230,
              "phase": 51.52,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIsland:tree:32",
              "x": 457,
              "y": 315,
              "phase": 49.33,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            }
          ],
          "tallGrass": [
            {
              "id": "prototypeIsland:grass:1",
              "x": 309,
              "y": 208,
              "phase": 0.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:2",
              "x": 320,
              "y": 222,
              "phase": 1.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:3",
              "x": 349,
              "y": 212,
              "phase": 2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:4",
              "x": 368,
              "y": 227,
              "phase": 2.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:5",
              "x": 380,
              "y": 204,
              "phase": 3.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:6",
              "x": 319,
              "y": 160,
              "phase": 4.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:7",
              "x": 385,
              "y": 178,
              "phase": 5.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:8",
              "x": 343,
              "y": 280,
              "phase": 6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:9",
              "x": 371,
              "y": 290,
              "phase": 6.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:10",
              "x": 380,
              "y": 317,
              "phase": 7.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:11",
              "x": 308,
              "y": 358,
              "phase": 8.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:12",
              "x": 294,
              "y": 383,
              "phase": 9.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:13",
              "x": 304,
              "y": 402,
              "phase": 10,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:14",
              "x": 376,
              "y": 402,
              "phase": 10.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:15",
              "x": 392,
              "y": 361,
              "phase": 11.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:16",
              "x": 254,
              "y": 303,
              "phase": 12.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:17",
              "x": 268,
              "y": 304,
              "phase": 13.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:18",
              "x": 246,
              "y": 241,
              "phase": 14,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:19",
              "x": 290,
              "y": 302,
              "phase": 14.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:20",
              "x": 391,
              "y": 425,
              "phase": 15.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:22",
              "x": 455,
              "y": 230,
              "phase": 17.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:23",
              "x": 469,
              "y": 244,
              "phase": 18,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:25",
              "x": 269,
              "y": 159,
              "phase": 19.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:26",
              "x": 220,
              "y": 189,
              "phase": 20.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:27",
              "x": 414,
              "y": 160,
              "phase": 21.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:28",
              "x": 461,
              "y": 171,
              "phase": 22,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:29",
              "x": 220,
              "y": 363,
              "phase": 22.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:30",
              "x": 470,
              "y": 364,
              "phase": 23.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:21",
              "x": 425,
              "y": 426,
              "phase": 22.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:24",
              "x": 437,
              "y": 426,
              "phase": 23.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIsland:grass:31",
              "x": 468,
              "y": 425,
              "phase": 24.4,
              "width": 13,
              "flowerType": null
            }
          ],
          "rocks": [
            {
              "id": "prototypeIsland:rock:1",
              "x": 299,
              "y": 176,
              "variant": "plain"
            },
            {
              "id": "prototypeIsland:rock:4",
              "x": 380,
              "y": 317,
              "variant": "plain"
            },
            {
              "id": "prototypeIsland:rock:5",
              "x": 235,
              "y": 354,
              "variant": "plain"
            },
            {
              "id": "prototypeIsland:rock:6",
              "x": 301,
              "y": 352,
              "variant": "plain"
            },
            {
              "id": "prototypeIsland:rock:7",
              "x": 456,
              "y": 384,
              "variant": "plain"
            },
            {
              "id": "prototypeIsland:rock:8",
              "x": 272,
              "y": 232,
              "variant": "plain"
            }
          ],
          "sceneryRocks": [
            {
              "id": "prototypeIsland:sceneryRock:1",
              "x": 237,
              "y": 152,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:2",
              "x": 462,
              "y": 346,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:3",
              "x": 387,
              "y": 170,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:4",
              "x": 238,
              "y": 415,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:5",
              "x": 468,
              "y": 431,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:6",
              "x": 215,
              "y": 222,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:7",
              "x": 476,
              "y": 194,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIsland:sceneryRock:8",
              "x": 222,
              "y": 341,
              "collision": {
                "width": 10,
                "height": 6
              }
            }
          ],
          "harvestFlowers": [
            {
              "id": "prototypeIsland:flower:1",
              "x": 293,
              "y": 382,
              "phase": 0.4,
              "type": "white"
            },
            {
              "id": "prototypeIsland:flower:2",
              "x": 269,
              "y": 157,
              "phase": 1.2,
              "type": "white"
            },
            {
              "id": "prototypeIsland:flower:4",
              "x": 317,
              "y": 221,
              "phase": 2.8,
              "type": "blue"
            },
            {
              "id": "prototypeIsland:flower:5",
              "x": 392,
              "y": 362,
              "phase": 3.6,
              "type": "blue"
            }
          ],
          "houses": [
            {
              "id": "prototypeIsland:house:1",
              "x": 436,
              "y": 196,
              "variant": "default",
              "collision": {
                "width": 48,
                "height": 30
              }
            }
          ]
        },
        "enemySpawns": [],
        "terrain": {
          "cellSize": 8,
          "defaultType": "void",
          "regions": [
            {
              "type": "grass",
              "x": 200,
              "y": 128,
              "width": 128,
              "height": 24
            },
            {
              "type": "water",
              "x": 328,
              "y": 128,
              "width": 40,
              "height": 16
            },
            {
              "type": "grass",
              "x": 368,
              "y": 128,
              "width": 128,
              "height": 16
            },
            {
              "type": "water",
              "x": 328,
              "y": 144,
              "width": 32,
              "height": 8
            },
            {
              "type": "grass",
              "x": 360,
              "y": 144,
              "width": 136,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 152,
              "width": 136,
              "height": 16
            },
            {
              "type": "water",
              "x": 336,
              "y": 152,
              "width": 32,
              "height": 8
            },
            {
              "type": "grass",
              "x": 368,
              "y": 152,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 336,
              "y": 160,
              "width": 40,
              "height": 8
            },
            {
              "type": "grass",
              "x": 376,
              "y": 160,
              "width": 120,
              "height": 16
            },
            {
              "type": "grass",
              "x": 200,
              "y": 168,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 328,
              "y": 168,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 176,
              "width": 120,
              "height": 8
            },
            {
              "type": "water",
              "x": 320,
              "y": 176,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 368,
              "y": 176,
              "width": 128,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 184,
              "width": 128,
              "height": 16
            },
            {
              "type": "water",
              "x": 328,
              "y": 184,
              "width": 32,
              "height": 16
            },
            {
              "type": "grass",
              "x": 360,
              "y": 184,
              "width": 136,
              "height": 16
            },
            {
              "type": "grass",
              "x": 200,
              "y": 200,
              "width": 296,
              "height": 48
            },
            {
              "type": "grass",
              "x": 200,
              "y": 248,
              "width": 80,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 280,
              "y": 248,
              "width": 112,
              "height": 8
            },
            {
              "type": "grass",
              "x": 392,
              "y": 248,
              "width": 104,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 256,
              "width": 40,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 240,
              "y": 256,
              "width": 176,
              "height": 8
            },
            {
              "type": "grass",
              "x": 416,
              "y": 256,
              "width": 80,
              "height": 8
            },
            {
              "type": "grass",
              "x": 120,
              "y": 264,
              "width": 96,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 216,
              "y": 264,
              "width": 80,
              "height": 8
            },
            {
              "type": "grass",
              "x": 296,
              "y": 264,
              "width": 80,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 376,
              "y": 264,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 440,
              "y": 264,
              "width": 136,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 272,
              "width": 144,
              "height": 8
            },
            {
              "type": "grass",
              "x": 264,
              "y": 272,
              "width": 136,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 400,
              "y": 272,
              "width": 176,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 280,
              "width": 112,
              "height": 8
            },
            {
              "type": "grass",
              "x": 232,
              "y": 280,
              "width": 200,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 432,
              "y": 280,
              "width": 144,
              "height": 8
            },
            {
              "type": "grass",
              "x": 120,
              "y": 288,
              "width": 224,
              "height": 8
            },
            {
              "type": "water",
              "x": 344,
              "y": 288,
              "width": 16,
              "height": 8
            },
            {
              "type": "grass",
              "x": 360,
              "y": 288,
              "width": 216,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 296,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 328,
              "y": 296,
              "width": 40,
              "height": 8
            },
            {
              "type": "grass",
              "x": 368,
              "y": 296,
              "width": 128,
              "height": 40
            },
            {
              "type": "grass",
              "x": 200,
              "y": 304,
              "width": 120,
              "height": 16
            },
            {
              "type": "water",
              "x": 320,
              "y": 304,
              "width": 48,
              "height": 16
            },
            {
              "type": "grass",
              "x": 200,
              "y": 320,
              "width": 128,
              "height": 24
            },
            {
              "type": "water",
              "x": 328,
              "y": 320,
              "width": 40,
              "height": 16
            },
            {
              "type": "water",
              "x": 328,
              "y": 336,
              "width": 32,
              "height": 8
            },
            {
              "type": "grass",
              "x": 360,
              "y": 336,
              "width": 136,
              "height": 24
            },
            {
              "type": "grass",
              "x": 200,
              "y": 344,
              "width": 120,
              "height": 40
            },
            {
              "type": "water",
              "x": 320,
              "y": 344,
              "width": 40,
              "height": 16
            },
            {
              "type": "water",
              "x": 320,
              "y": 360,
              "width": 48,
              "height": 24
            },
            {
              "type": "grass",
              "x": 368,
              "y": 360,
              "width": 128,
              "height": 40
            },
            {
              "type": "grass",
              "x": 200,
              "y": 384,
              "width": 112,
              "height": 40
            },
            {
              "type": "water",
              "x": 312,
              "y": 384,
              "width": 56,
              "height": 16
            },
            {
              "type": "water",
              "x": 312,
              "y": 400,
              "width": 48,
              "height": 16
            },
            {
              "type": "grass",
              "x": 360,
              "y": 400,
              "width": 136,
              "height": 16
            },
            {
              "type": "water",
              "x": 312,
              "y": 416,
              "width": 56,
              "height": 8
            },
            {
              "type": "grass",
              "x": 368,
              "y": 416,
              "width": 128,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 424,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 304,
              "y": 424,
              "width": 56,
              "height": 8
            },
            {
              "type": "grass",
              "x": 360,
              "y": 424,
              "width": 136,
              "height": 8
            }
          ]
        },
        "collision": {
          "waterRects": []
        },
        "npcs": [
          {
            "id": "prototypeIsland:npc:1",
            "type": "shopkeeper",
            "name": "Marnie",
            "x": 422,
            "y": 207,
            "interactionRadius": 24
          },
          {
            "id": "prototypeIsland:npc:2",
            "type": "classResetCrystal",
            "x": 426,
            "y": 348,
            "interactionRadius": 28
          },
          {
            "id": "prototypeIsland:npc:3",
            "type": "craftingTable",
            "x": 395,
            "y": 221,
            "interactionRadius": 24
          },
          {
            "id": "prototypeIsland:npc:camoGuy",
            "type": "camoGuy",
            "name": "Cam",
            "x": 249,
            "y": 173,
            "interactionRadius": 24
          }
        ]
      },
      "prototypeIslandWest": {
        "name": "Prototype Island West",
        "dimensions": {
          "width": 1060,
          "height": 560
        },
        "playerSpawns": [
          {
            "id": "center",
            "x": 563,
            "y": 431
          },
          {
            "id": "eastBridge",
            "x": 864,
            "y": 280
          },
          {
            "id": "waterfallTrail",
            "x": 479,
            "y": 115
          }
        ],
        "portals": [
          {
            "id": "prototypeIslandWest:portal:east",
            "x": 868,
            "y": 254,
            "width": 12,
            "height": 52,
            "targetMapId": "prototypeIsland",
            "targetSpawnId": "westBridge"
          },
          {
            "id": "prototypeIslandWest:portal:crabBeach",
            "x": 539,
            "y": 484,
            "width": 50,
            "height": 10,
            "targetMapId": "crabBeach",
            "targetSpawnId": "westDune"
          },
          {
            "id": "prototypeIslandWest:portal:waterfallGrove",
            "x": 464,
            "y": 80,
            "width": 32,
            "height": 16,
            "targetMapId": "waterfallGrove",
            "targetSpawnId": "southEntrance"
          }
        ],
        "environment": {
          "trees": [
            {
              "id": "prototypeIslandWest:tree:1",
              "x": 211,
              "y": 139,
              "phase": 1.17,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:2",
              "x": 213,
              "y": 417,
              "phase": 1.9,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:3",
              "x": 238,
              "y": 160,
              "phase": 2.63,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:4",
              "x": 247,
              "y": 417,
              "phase": 3.36,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:5",
              "x": 256,
              "y": 138,
              "phase": 4.09,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:9",
              "x": 296,
              "y": 134,
              "phase": 7.010000000000002,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:13",
              "x": 338,
              "y": 145,
              "phase": 9.930000000000003,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:14",
              "x": 404,
              "y": 420,
              "phase": 10.660000000000004,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:15",
              "x": 369,
              "y": 133,
              "phase": 11.390000000000004,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:17",
              "x": 405,
              "y": 136,
              "phase": 12.850000000000005,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:18",
              "x": 446,
              "y": 418,
              "phase": 13.580000000000005,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:19",
              "x": 432,
              "y": 149,
              "phase": 14.310000000000006,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:20",
              "x": 500,
              "y": 418,
              "phase": 15.040000000000006,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:21",
              "x": 366,
              "y": 241,
              "phase": 15.770000000000007,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:22",
              "x": 469,
              "y": 358,
              "phase": 16.500000000000007,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:24",
              "x": 484,
              "y": 381,
              "phase": 17.960000000000008,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:26",
              "x": 496,
              "y": 357,
              "phase": 19.42000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:27",
              "x": 602,
              "y": 207,
              "phase": 20.15000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:28",
              "x": 639,
              "y": 418,
              "phase": 20.88000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:29",
              "x": 646,
              "y": 139,
              "phase": 21.61000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:30",
              "x": 709,
              "y": 419,
              "phase": 22.34000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:33",
              "x": 685,
              "y": 148,
              "phase": 24.530000000000012,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:34",
              "x": 745,
              "y": 394,
              "phase": 25.260000000000012,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:35",
              "x": 723,
              "y": 135,
              "phase": 25.990000000000013,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:38",
              "x": 779,
              "y": 362,
              "phase": 28.180000000000014,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:40",
              "x": 304,
              "y": 410,
              "phase": 29.640000000000015,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:41",
              "x": 268,
              "y": 170,
              "phase": 30.370000000000015,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:42",
              "x": 234,
              "y": 394,
              "phase": 31.100000000000016,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:43",
              "x": 318,
              "y": 168,
              "phase": 31.830000000000016,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:46",
              "x": 336,
              "y": 420,
              "phase": 34.02000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:47",
              "x": 390,
              "y": 173,
              "phase": 34.75000000000001,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:49",
              "x": 417,
              "y": 169,
              "phase": 36.21,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:50",
              "x": 377,
              "y": 404,
              "phase": 36.94,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:51",
              "x": 448,
              "y": 169,
              "phase": 37.669999999999995,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:52",
              "x": 432,
              "y": 392,
              "phase": 38.39999999999999,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:53",
              "x": 434,
              "y": 189,
              "phase": 39.12999999999999,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:54",
              "x": 466,
              "y": 422,
              "phase": 39.859999999999985,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:56",
              "x": 522,
              "y": 386,
              "phase": 41.31999999999998,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:57",
              "x": 524,
              "y": 229,
              "phase": 42.049999999999976,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:58",
              "x": 621,
              "y": 334,
              "phase": 42.77999999999997,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:59",
              "x": 506,
              "y": 169,
              "phase": 43.50999999999997,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:60",
              "x": 655,
              "y": 358,
              "phase": 44.23999999999997,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:61",
              "x": 613,
              "y": 179,
              "phase": 44.96999999999996,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:62",
              "x": 620,
              "y": 384,
              "phase": 45.69999999999996,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:63",
              "x": 653,
              "y": 173,
              "phase": 46.42999999999996,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:64",
              "x": 746,
              "y": 304,
              "phase": 47.159999999999954,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:65",
              "x": 681,
              "y": 188,
              "phase": 47.88999999999995,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:66",
              "x": 671,
              "y": 404,
              "phase": 48.61999999999995,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:67",
              "x": 712,
              "y": 182,
              "phase": 49.349999999999945,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:68",
              "x": 700,
              "y": 313,
              "phase": 50.07999999999994,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:69",
              "x": 745,
              "y": 175,
              "phase": 50.80999999999994,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:70",
              "x": 781,
              "y": 415,
              "phase": 51.539999999999935,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:71",
              "x": 783,
              "y": 179,
              "phase": 52.26999999999993,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:73",
              "x": 210,
              "y": 176,
              "phase": 53.729999999999926,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:74",
              "x": 767,
              "y": 147,
              "phase": 54.45999999999992,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:76",
              "x": 790,
              "y": 206,
              "phase": 55.919999999999916,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:78",
              "x": 790,
              "y": 236,
              "phase": 57.37999999999991,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:80",
              "x": 239,
              "y": 287,
              "phase": 58.839999999999904,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:81",
              "x": 209,
              "y": 310,
              "phase": 59.5699999999999,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:82",
              "x": 791,
              "y": 314,
              "phase": 60.2999999999999,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:83",
              "x": 218,
              "y": 356,
              "phase": 61.029999999999895,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:85",
              "x": 210,
              "y": 386,
              "phase": 62.48999999999989,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:87",
              "x": 251,
              "y": 203,
              "phase": 63.94999999999988,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:88",
              "x": 341,
              "y": 185,
              "phase": 64.67999999999988,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:89",
              "x": 606,
              "y": 231,
              "phase": 65.40999999999988,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:90",
              "x": 693,
              "y": 358,
              "phase": 66.13999999999989,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:91",
              "x": 334,
              "y": 387,
              "phase": 66.86999999999989,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:92",
              "x": 606,
              "y": 288,
              "phase": 67.5999999999999,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:93",
              "x": 660,
              "y": 297,
              "phase": 67.58,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:94",
              "x": 347,
              "y": 255,
              "phase": 68.31,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:95",
              "x": 259,
              "y": 312,
              "phase": 69.04,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:23",
              "x": 311,
              "y": 330,
              "phase": 63.2,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:32",
              "x": 397,
              "y": 337,
              "phase": 63.93,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:36",
              "x": 430,
              "y": 232,
              "phase": 64.66,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:55",
              "x": 530,
              "y": 291,
              "phase": 65.39,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:72",
              "x": 745,
              "y": 351,
              "phase": 66.12,
              "fireImmune": true,
              "nonInteractive": true
            },
            {
              "id": "prototypeIslandWest:tree:77",
              "x": 440,
              "y": 256,
              "phase": 66.85,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:79",
              "x": 395,
              "y": 276,
              "phase": 67.58,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "prototypeIslandWest:tree:96",
              "x": 207,
              "y": 265,
              "phase": 69.77,
              "fireImmune": true,
              "nonInteractive": true
            }
          ],
          "tallGrass": [
            {
              "id": "prototypeIslandWest:grass:1",
              "x": 315,
              "y": 275,
              "phase": 0.7,
              "width": 16,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:2",
              "x": 335,
              "y": 292,
              "phase": 1.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:3",
              "x": 492,
              "y": 315,
              "phase": 2.1,
              "width": 18,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:4",
              "x": 510,
              "y": 292,
              "phase": 2.8,
              "width": 14,
              "flowerType": "yellow"
            },
            {
              "id": "prototypeIslandWest:grass:5",
              "x": 630,
              "y": 293,
              "phase": 3.6,
              "width": 17,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:6",
              "x": 705,
              "y": 292,
              "phase": 4.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:7",
              "x": 404,
              "y": 196,
              "phase": 5.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:8",
              "x": 359,
              "y": 187,
              "phase": 6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:9",
              "x": 509,
              "y": 141,
              "phase": 6.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:10",
              "x": 512,
              "y": 190,
              "phase": 7.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:11",
              "x": 536,
              "y": 237,
              "phase": 8.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:12",
              "x": 611,
              "y": 239,
              "phase": 9.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:13",
              "x": 529,
              "y": 299,
              "phase": 10,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:14",
              "x": 601,
              "y": 300,
              "phase": 10.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:15",
              "x": 501,
              "y": 329,
              "phase": 11.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:16",
              "x": 623,
              "y": 197,
              "phase": 12.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:17",
              "x": 771,
              "y": 253,
              "phase": 13.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:18",
              "x": 760,
              "y": 211,
              "phase": 14,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:19",
              "x": 219,
              "y": 340,
              "phase": 14.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:20",
              "x": 234,
              "y": 363,
              "phase": 15.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:21",
              "x": 247,
              "y": 380,
              "phase": 16.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:22",
              "x": 243,
              "y": 349,
              "phase": 17.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:23",
              "x": 255,
              "y": 362,
              "phase": 18,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:24",
              "x": 265,
              "y": 383,
              "phase": 18.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:25",
              "x": 247,
              "y": 322,
              "phase": 19.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "prototypeIslandWest:grass:26",
              "x": 274,
              "y": 319,
              "phase": 20.4,
              "width": 13,
              "flowerType": null
            }
          ],
          "rocks": [
            {
              "id": "prototypeIslandWest:rock:1",
              "x": 265,
              "y": 350,
              "variant": "plain"
            },
            {
              "id": "prototypeIslandWest:rock:2",
              "x": 405,
              "y": 250,
              "variant": "grass"
            },
            {
              "id": "prototypeIslandWest:rock:3",
              "x": 667,
              "y": 339,
              "variant": "plain"
            },
            {
              "id": "prototypeIslandWest:rock:4",
              "x": 723,
              "y": 208,
              "variant": "grass"
            },
            {
              "id": "prototypeIslandWest:rock:5",
              "x": 645,
              "y": 391,
              "variant": "plain"
            }
          ],
          "sceneryRocks": [
            {
              "id": "prototypeIslandWest:sceneryRock:1",
              "x": 295,
              "y": 171,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIslandWest:sceneryRock:2",
              "x": 499,
              "y": 399,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "prototypeIslandWest:sceneryRock:3",
              "x": 762,
              "y": 194,
              "collision": {
                "width": 10,
                "height": 6
              }
            }
          ],
          "harvestFlowers": [
            {
              "id": "prototypeIslandWest:flower:1",
              "x": 500,
              "y": 327,
              "phase": 0.4,
              "type": "white"
            },
            {
              "id": "prototypeIslandWest:flower:2",
              "x": 358,
              "y": 182,
              "phase": 1.2,
              "type": "blue"
            },
            {
              "id": "prototypeIslandWest:flower:3",
              "x": 619,
              "y": 197,
              "phase": 2,
              "type": "white"
            },
            {
              "id": "prototypeIslandWest:flower:4",
              "x": 760,
              "y": 209,
              "phase": 2.8,
              "type": "blue"
            },
            {
              "id": "prototypeIslandWest:flower:5",
              "x": 236,
              "y": 361,
              "phase": 3.6,
              "type": "white"
            },
            {
              "id": "prototypeIslandWest:flower:6",
              "x": 246,
              "y": 377,
              "phase": 4.4,
              "type": "blue"
            }
          ],
          "houses": []
        },
        "enemySpawns": [
          {
            "id": "prototypeIslandWest:slime:1",
            "type": "slime",
            "level": 1,
            "x": 683,
            "y": 213,
            "phase": 0.3,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:2",
            "type": "slime",
            "level": 1,
            "x": 714,
            "y": 377,
            "phase": 1.2,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:3",
            "type": "slime",
            "level": 1,
            "x": 738,
            "y": 245,
            "phase": 2.1,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:4",
            "type": "slime",
            "level": 1,
            "x": 283,
            "y": 204,
            "phase": 3,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:5",
            "type": "slime",
            "level": 1,
            "x": 339,
            "y": 222,
            "phase": 3.9,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:6",
            "type": "slime",
            "level": 1,
            "x": 388,
            "y": 202,
            "phase": 4.8,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:7",
            "type": "slime",
            "level": 1,
            "x": 296,
            "y": 358,
            "phase": 5.7,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          },
          {
            "id": "prototypeIslandWest:slime:8",
            "type": "slime",
            "level": 1,
            "x": 401,
            "y": 363,
            "phase": 6.6,
            "wanderRadiusX": 18,
            "wanderRadiusY": 13
          }
        ],
        "terrain": {
          "cellSize": 8,
          "defaultType": "void",
          "regions": [
            {
              "type": "dirt",
              "x": 464,
              "y": 80,
              "width": 32,
              "height": 80
            },
            {
              "type": "grass",
              "x": 608,
              "y": 120,
              "width": 8,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 128,
              "width": 264,
              "height": 32
            },
            {
              "type": "grass",
              "x": 496,
              "y": 128,
              "width": 24,
              "height": 40
            },
            {
              "type": "water",
              "x": 520,
              "y": 128,
              "width": 80,
              "height": 40
            },
            {
              "type": "grass",
              "x": 600,
              "y": 128,
              "width": 200,
              "height": 56
            },
            {
              "type": "grass",
              "x": 200,
              "y": 160,
              "width": 256,
              "height": 24
            },
            {
              "type": "dirt",
              "x": 456,
              "y": 160,
              "width": 40,
              "height": 24
            },
            {
              "type": "grass",
              "x": 496,
              "y": 168,
              "width": 32,
              "height": 24
            },
            {
              "type": "water",
              "x": 528,
              "y": 168,
              "width": 72,
              "height": 16
            },
            {
              "type": "grass",
              "x": 200,
              "y": 184,
              "width": 248,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 448,
              "y": 184,
              "width": 48,
              "height": 8
            },
            {
              "type": "water",
              "x": 528,
              "y": 184,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 592,
              "y": 184,
              "width": 208,
              "height": 56
            },
            {
              "type": "grass",
              "x": 200,
              "y": 192,
              "width": 240,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 440,
              "y": 192,
              "width": 40,
              "height": 8
            },
            {
              "type": "grass",
              "x": 480,
              "y": 192,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 536,
              "y": 192,
              "width": 56,
              "height": 40
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 200,
              "width": 24,
              "height": 8
            },
            {
              "type": "grass",
              "x": 144,
              "y": 200,
              "width": 296,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 440,
              "y": 200,
              "width": 32,
              "height": 16
            },
            {
              "type": "grass",
              "x": 472,
              "y": 200,
              "width": 64,
              "height": 16
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 208,
              "width": 104,
              "height": 8
            },
            {
              "type": "grass",
              "x": 224,
              "y": 208,
              "width": 216,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 216,
              "width": 120,
              "height": 8
            },
            {
              "type": "grass",
              "x": 240,
              "y": 216,
              "width": 200,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 440,
              "y": 216,
              "width": 40,
              "height": 8
            },
            {
              "type": "grass",
              "x": 480,
              "y": 216,
              "width": 56,
              "height": 16
            },
            {
              "type": "dirt",
              "x": 120,
              "y": 224,
              "width": 136,
              "height": 8
            },
            {
              "type": "grass",
              "x": 256,
              "y": 224,
              "width": 192,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 448,
              "y": 224,
              "width": 32,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 232,
              "width": 8,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 208,
              "y": 232,
              "width": 56,
              "height": 8
            },
            {
              "type": "grass",
              "x": 264,
              "y": 232,
              "width": 184,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 448,
              "y": 232,
              "width": 40,
              "height": 8
            },
            {
              "type": "grass",
              "x": 488,
              "y": 232,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 544,
              "y": 232,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 240,
              "width": 24,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 224,
              "y": 240,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 272,
              "y": 240,
              "width": 184,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 456,
              "y": 240,
              "width": 40,
              "height": 16
            },
            {
              "type": "grass",
              "x": 496,
              "y": 240,
              "width": 48,
              "height": 16
            },
            {
              "type": "water",
              "x": 544,
              "y": 240,
              "width": 56,
              "height": 112
            },
            {
              "type": "grass",
              "x": 600,
              "y": 240,
              "width": 200,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 248,
              "width": 32,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 232,
              "y": 248,
              "width": 56,
              "height": 8
            },
            {
              "type": "grass",
              "x": 288,
              "y": 248,
              "width": 168,
              "height": 8
            },
            {
              "type": "grass",
              "x": 600,
              "y": 248,
              "width": 72,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 672,
              "y": 248,
              "width": 32,
              "height": 8
            },
            {
              "type": "grass",
              "x": 704,
              "y": 248,
              "width": 96,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 256,
              "width": 48,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 248,
              "y": 256,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 296,
              "y": 256,
              "width": 168,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 464,
              "y": 256,
              "width": 40,
              "height": 16
            },
            {
              "type": "grass",
              "x": 504,
              "y": 256,
              "width": 40,
              "height": 24
            },
            {
              "type": "grass",
              "x": 600,
              "y": 256,
              "width": 64,
              "height": 16
            },
            {
              "type": "dirt",
              "x": 664,
              "y": 256,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 728,
              "y": 256,
              "width": 72,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 264,
              "width": 56,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 256,
              "y": 264,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 320,
              "y": 264,
              "width": 144,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 664,
              "y": 264,
              "width": 88,
              "height": 8
            },
            {
              "type": "grass",
              "x": 752,
              "y": 264,
              "width": 24,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 776,
              "y": 264,
              "width": 16,
              "height": 8
            },
            {
              "type": "grass",
              "x": 792,
              "y": 264,
              "width": 88,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 272,
              "width": 64,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 264,
              "y": 272,
              "width": 72,
              "height": 8
            },
            {
              "type": "grass",
              "x": 336,
              "y": 272,
              "width": 120,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 456,
              "y": 272,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 600,
              "y": 272,
              "width": 72,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 672,
              "y": 272,
              "width": 208,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 280,
              "width": 72,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 272,
              "y": 280,
              "width": 88,
              "height": 8
            },
            {
              "type": "grass",
              "x": 360,
              "y": 280,
              "width": 64,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 424,
              "y": 280,
              "width": 72,
              "height": 8
            },
            {
              "type": "grass",
              "x": 496,
              "y": 280,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 600,
              "y": 280,
              "width": 96,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 696,
              "y": 280,
              "width": 184,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 288,
              "width": 88,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 288,
              "y": 288,
              "width": 96,
              "height": 8
            },
            {
              "type": "grass",
              "x": 384,
              "y": 288,
              "width": 24,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 408,
              "y": 288,
              "width": 80,
              "height": 8
            },
            {
              "type": "grass",
              "x": 488,
              "y": 288,
              "width": 56,
              "height": 8
            },
            {
              "type": "grass",
              "x": 600,
              "y": 288,
              "width": 120,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 720,
              "y": 288,
              "width": 112,
              "height": 8
            },
            {
              "type": "grass",
              "x": 832,
              "y": 288,
              "width": 48,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 296,
              "width": 104,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 304,
              "y": 296,
              "width": 176,
              "height": 8
            },
            {
              "type": "grass",
              "x": 480,
              "y": 296,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 600,
              "y": 296,
              "width": 200,
              "height": 56
            },
            {
              "type": "grass",
              "x": 200,
              "y": 304,
              "width": 128,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 328,
              "y": 304,
              "width": 136,
              "height": 8
            },
            {
              "type": "grass",
              "x": 464,
              "y": 304,
              "width": 80,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 312,
              "width": 152,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 352,
              "y": 312,
              "width": 104,
              "height": 8
            },
            {
              "type": "grass",
              "x": 456,
              "y": 312,
              "width": 88,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 320,
              "width": 344,
              "height": 40
            },
            {
              "type": "water",
              "x": 544,
              "y": 352,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 608,
              "y": 352,
              "width": 192,
              "height": 72
            },
            {
              "type": "grass",
              "x": 200,
              "y": 360,
              "width": 336,
              "height": 56
            },
            {
              "type": "water",
              "x": 536,
              "y": 360,
              "width": 72,
              "height": 56
            },
            {
              "type": "grass",
              "x": 200,
              "y": 416,
              "width": 328,
              "height": 8
            },
            {
              "type": "water",
              "x": 528,
              "y": 416,
              "width": 80,
              "height": 8
            },
            {
              "type": "grass",
              "x": 200,
              "y": 424,
              "width": 312,
              "height": 8
            },
            {
              "type": "water",
              "x": 512,
              "y": 424,
              "width": 104,
              "height": 8
            },
            {
              "type": "grass",
              "x": 616,
              "y": 424,
              "width": 184,
              "height": 8
            },
            {
              "type": "grass",
              "x": 248,
              "y": 432,
              "width": 40,
              "height": 64
            },
            {
              "type": "water",
              "x": 544,
              "y": 432,
              "width": 40,
              "height": 64
            }
          ]
        },
        "collision": {
          "waterRects": []
        },
        "npcs": []
      },
      "crabBeach": {
        "name": "Crab Beach",
        "dimensions": {
          "width": 920,
          "height": 560
        },
        "playerSpawns": [
          {
            "id": "westDune",
            "x": 416,
            "y": 129
          }
        ],
        "portals": [
          {
            "id": "crabBeach:portal:west",
            "x": 391,
            "y": 57,
            "width": 50,
            "height": 20,
            "targetMapId": "prototypeIslandWest",
            "targetSpawnId": "center"
          }
        ],
        "environment": {
          "trees": [],
          "tallGrass": [
            {
              "id": "crabBeach:grass:1",
              "x": 243,
              "y": 377,
              "phase": 0.4,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "crabBeach:grass:2",
              "x": 232,
              "y": 396,
              "phase": 1.2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "crabBeach:grass:3",
              "x": 283,
              "y": 170,
              "phase": 2,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "crabBeach:grass:4",
              "x": 515,
              "y": 188,
              "phase": 2.8,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "crabBeach:grass:5",
              "x": 533,
              "y": 190,
              "phase": 3.6,
              "width": 13,
              "flowerType": null
            },
            {
              "id": "crabBeach:grass:6",
              "x": 563,
              "y": 217,
              "phase": 4.4,
              "width": 13,
              "flowerType": null
            }
          ],
          "rocks": [
            {
              "id": "crabBeach:rock:1",
              "x": 228,
              "y": 222,
              "variant": "plain"
            },
            {
              "id": "crabBeach:rock:2",
              "x": 322,
              "y": 360,
              "variant": "plain"
            },
            {
              "id": "crabBeach:rock:3",
              "x": 432,
              "y": 209,
              "variant": "plain"
            }
          ],
          "sceneryRocks": [
            {
              "id": "crabBeach:sceneryRock:1",
              "x": 208,
              "y": 269,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "crabBeach:sceneryRock:2",
              "x": 308,
              "y": 166,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "crabBeach:sceneryRock:3",
              "x": 555,
              "y": 210,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "crabBeach:sceneryRock:4",
              "x": 515,
              "y": 407,
              "collision": {
                "width": 10,
                "height": 6
              }
            }
          ],
          "harvestFlowers": [],
          "houses": []
        },
        "enemySpawns": [
          {
            "id": "crabBeach:crab:1",
            "type": "crab",
            "level": 3,
            "x": 520,
            "y": 220,
            "phase": 0.4,
            "wanderRadiusX": 24,
            "wanderRadiusY": 10
          },
          {
            "id": "crabBeach:crab:2",
            "type": "crab",
            "level": 3,
            "x": 397,
            "y": 330,
            "phase": 1.1,
            "wanderRadiusX": 24,
            "wanderRadiusY": 10
          },
          {
            "id": "crabBeach:crab:3",
            "type": "crab",
            "level": 4,
            "x": 310,
            "y": 226,
            "phase": 2.1,
            "wanderRadiusX": 26,
            "wanderRadiusY": 10
          },
          {
            "id": "crabBeach:crab:4",
            "type": "crab",
            "level": 4,
            "x": 187,
            "y": 346,
            "phase": 3.2,
            "wanderRadiusX": 26,
            "wanderRadiusY": 10
          },
          {
            "id": "crabBeach:slime:1",
            "type": "crab",
            "level": 1,
            "x": 275,
            "y": 276,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:5",
            "type": "crab",
            "level": 1,
            "x": 412,
            "y": 434,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:6",
            "type": "crab",
            "level": 1,
            "x": 463,
            "y": 329,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:7",
            "type": "crab",
            "level": 1,
            "x": 267,
            "y": 359,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:8",
            "type": "crab",
            "level": 1,
            "x": 340,
            "y": 398,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:9",
            "type": "crab",
            "level": 1,
            "x": 506,
            "y": 472,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:10",
            "type": "crab",
            "level": 1,
            "x": 449,
            "y": 257,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:11",
            "type": "crab",
            "level": 1,
            "x": 628,
            "y": 245,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:12",
            "type": "crab",
            "level": 1,
            "x": 621,
            "y": 430,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:13",
            "type": "crab",
            "level": 1,
            "x": 356,
            "y": 277,
            "phase": 3.9
          },
          {
            "id": "crabBeach:crab:14",
            "type": "crab",
            "level": 1,
            "x": 234,
            "y": 464,
            "phase": 3.9
          }
        ],
        "terrain": {
          "cellSize": 8,
          "defaultType": "void",
          "regions": [
            {
              "type": "water",
              "x": 400,
              "y": 56,
              "width": 32,
              "height": 80
            },
            {
              "type": "water",
              "x": 152,
              "y": 136,
              "width": 528,
              "height": 24
            },
            {
              "type": "water",
              "x": 152,
              "y": 160,
              "width": 128,
              "height": 8
            },
            {
              "type": "sand",
              "x": 280,
              "y": 160,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 344,
              "y": 160,
              "width": 336,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 168,
              "width": 112,
              "height": 8
            },
            {
              "type": "sand",
              "x": 264,
              "y": 168,
              "width": 112,
              "height": 8
            },
            {
              "type": "water",
              "x": 376,
              "y": 168,
              "width": 304,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 176,
              "width": 88,
              "height": 8
            },
            {
              "type": "sand",
              "x": 240,
              "y": 176,
              "width": 160,
              "height": 8
            },
            {
              "type": "water",
              "x": 400,
              "y": 176,
              "width": 120,
              "height": 8
            },
            {
              "type": "sand",
              "x": 520,
              "y": 176,
              "width": 32,
              "height": 8
            },
            {
              "type": "water",
              "x": 552,
              "y": 176,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 184,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 232,
              "y": 184,
              "width": 176,
              "height": 8
            },
            {
              "type": "water",
              "x": 408,
              "y": 184,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 488,
              "y": 184,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 560,
              "y": 184,
              "width": 120,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 192,
              "width": 64,
              "height": 8
            },
            {
              "type": "sand",
              "x": 216,
              "y": 192,
              "width": 208,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 192,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 480,
              "y": 192,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 568,
              "y": 192,
              "width": 112,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 200,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 208,
              "y": 200,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 296,
              "y": 200,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 336,
              "y": 200,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 440,
              "y": 200,
              "width": 32,
              "height": 8
            },
            {
              "type": "sand",
              "x": 472,
              "y": 200,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 576,
              "y": 200,
              "width": 104,
              "height": 16
            },
            {
              "type": "water",
              "x": 152,
              "y": 208,
              "width": 48,
              "height": 8
            },
            {
              "type": "sand",
              "x": 200,
              "y": 208,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 288,
              "y": 208,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 344,
              "y": 208,
              "width": 232,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 216,
              "width": 40,
              "height": 32
            },
            {
              "type": "sand",
              "x": 192,
              "y": 216,
              "width": 88,
              "height": 24
            },
            {
              "type": "water",
              "x": 280,
              "y": 216,
              "width": 72,
              "height": 24
            },
            {
              "type": "sand",
              "x": 352,
              "y": 216,
              "width": 232,
              "height": 8
            },
            {
              "type": "water",
              "x": 584,
              "y": 216,
              "width": 96,
              "height": 24
            },
            {
              "type": "sand",
              "x": 352,
              "y": 224,
              "width": 80,
              "height": 8
            },
            {
              "type": "water",
              "x": 432,
              "y": 224,
              "width": 48,
              "height": 8
            },
            {
              "type": "sand",
              "x": 480,
              "y": 224,
              "width": 104,
              "height": 8
            },
            {
              "type": "sand",
              "x": 352,
              "y": 232,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 232,
              "width": 64,
              "height": 8
            },
            {
              "type": "sand",
              "x": 488,
              "y": 232,
              "width": 96,
              "height": 8
            },
            {
              "type": "sand",
              "x": 192,
              "y": 240,
              "width": 96,
              "height": 8
            },
            {
              "type": "water",
              "x": 288,
              "y": 240,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 344,
              "y": 240,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 416,
              "y": 240,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 496,
              "y": 240,
              "width": 80,
              "height": 8
            },
            {
              "type": "water",
              "x": 576,
              "y": 240,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 248,
              "width": 32,
              "height": 24
            },
            {
              "type": "sand",
              "x": 184,
              "y": 248,
              "width": 112,
              "height": 8
            },
            {
              "type": "water",
              "x": 296,
              "y": 248,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 336,
              "y": 248,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 408,
              "y": 248,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 488,
              "y": 248,
              "width": 80,
              "height": 8
            },
            {
              "type": "water",
              "x": 568,
              "y": 248,
              "width": 112,
              "height": 8
            },
            {
              "type": "sand",
              "x": 184,
              "y": 256,
              "width": 120,
              "height": 8
            },
            {
              "type": "water",
              "x": 304,
              "y": 256,
              "width": 24,
              "height": 8
            },
            {
              "type": "sand",
              "x": 328,
              "y": 256,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 416,
              "y": 256,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 496,
              "y": 256,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 560,
              "y": 256,
              "width": 120,
              "height": 8
            },
            {
              "type": "sand",
              "x": 184,
              "y": 264,
              "width": 240,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 264,
              "width": 72,
              "height": 8
            },
            {
              "type": "sand",
              "x": 496,
              "y": 264,
              "width": 48,
              "height": 8
            },
            {
              "type": "water",
              "x": 544,
              "y": 264,
              "width": 136,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 272,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 192,
              "y": 272,
              "width": 248,
              "height": 8
            },
            {
              "type": "water",
              "x": 440,
              "y": 272,
              "width": 48,
              "height": 8
            },
            {
              "type": "sand",
              "x": 488,
              "y": 272,
              "width": 40,
              "height": 8
            },
            {
              "type": "water",
              "x": 528,
              "y": 272,
              "width": 152,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 280,
              "width": 48,
              "height": 8
            },
            {
              "type": "sand",
              "x": 200,
              "y": 280,
              "width": 248,
              "height": 8
            },
            {
              "type": "water",
              "x": 448,
              "y": 280,
              "width": 32,
              "height": 8
            },
            {
              "type": "sand",
              "x": 480,
              "y": 280,
              "width": 40,
              "height": 8
            },
            {
              "type": "water",
              "x": 520,
              "y": 280,
              "width": 160,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 288,
              "width": 72,
              "height": 24
            },
            {
              "type": "sand",
              "x": 224,
              "y": 288,
              "width": 288,
              "height": 8
            },
            {
              "type": "water",
              "x": 512,
              "y": 288,
              "width": 168,
              "height": 8
            },
            {
              "type": "sand",
              "x": 224,
              "y": 296,
              "width": 168,
              "height": 8
            },
            {
              "type": "water",
              "x": 392,
              "y": 296,
              "width": 48,
              "height": 8
            },
            {
              "type": "sand",
              "x": 440,
              "y": 296,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 504,
              "y": 296,
              "width": 176,
              "height": 8
            },
            {
              "type": "sand",
              "x": 224,
              "y": 304,
              "width": 160,
              "height": 8
            },
            {
              "type": "water",
              "x": 384,
              "y": 304,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 464,
              "y": 304,
              "width": 24,
              "height": 8
            },
            {
              "type": "water",
              "x": 488,
              "y": 304,
              "width": 192,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 312,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 232,
              "y": 312,
              "width": 144,
              "height": 8
            },
            {
              "type": "water",
              "x": 376,
              "y": 312,
              "width": 304,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 320,
              "width": 88,
              "height": 8
            },
            {
              "type": "sand",
              "x": 240,
              "y": 320,
              "width": 136,
              "height": 8
            },
            {
              "type": "water",
              "x": 376,
              "y": 320,
              "width": 192,
              "height": 8
            },
            {
              "type": "sand",
              "x": 568,
              "y": 320,
              "width": 24,
              "height": 8
            },
            {
              "type": "water",
              "x": 592,
              "y": 320,
              "width": 88,
              "height": 16
            },
            {
              "type": "water",
              "x": 152,
              "y": 328,
              "width": 96,
              "height": 24
            },
            {
              "type": "sand",
              "x": 248,
              "y": 328,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 376,
              "y": 328,
              "width": 176,
              "height": 8
            },
            {
              "type": "sand",
              "x": 552,
              "y": 328,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 248,
              "y": 336,
              "width": 136,
              "height": 8
            },
            {
              "type": "water",
              "x": 384,
              "y": 336,
              "width": 160,
              "height": 8
            },
            {
              "type": "sand",
              "x": 544,
              "y": 336,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 600,
              "y": 336,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 248,
              "y": 344,
              "width": 144,
              "height": 8
            },
            {
              "type": "water",
              "x": 392,
              "y": 344,
              "width": 144,
              "height": 8
            },
            {
              "type": "sand",
              "x": 536,
              "y": 344,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 608,
              "y": 344,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 352,
              "width": 88,
              "height": 8
            },
            {
              "type": "sand",
              "x": 240,
              "y": 352,
              "width": 176,
              "height": 8
            },
            {
              "type": "water",
              "x": 416,
              "y": 352,
              "width": 96,
              "height": 8
            },
            {
              "type": "sand",
              "x": 512,
              "y": 352,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 600,
              "y": 352,
              "width": 80,
              "height": 16
            },
            {
              "type": "water",
              "x": 152,
              "y": 360,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 232,
              "y": 360,
              "width": 192,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 360,
              "width": 64,
              "height": 8
            },
            {
              "type": "sand",
              "x": 488,
              "y": 360,
              "width": 112,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 368,
              "width": 72,
              "height": 32
            },
            {
              "type": "sand",
              "x": 224,
              "y": 368,
              "width": 96,
              "height": 8
            },
            {
              "type": "water",
              "x": 320,
              "y": 368,
              "width": 24,
              "height": 8
            },
            {
              "type": "sand",
              "x": 344,
              "y": 368,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 416,
              "y": 368,
              "width": 64,
              "height": 16
            },
            {
              "type": "sand",
              "x": 480,
              "y": 368,
              "width": 112,
              "height": 8
            },
            {
              "type": "water",
              "x": 592,
              "y": 368,
              "width": 88,
              "height": 8
            },
            {
              "type": "sand",
              "x": 224,
              "y": 376,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 312,
              "y": 376,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 352,
              "y": 376,
              "width": 64,
              "height": 8
            },
            {
              "type": "sand",
              "x": 480,
              "y": 376,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 584,
              "y": 376,
              "width": 96,
              "height": 8
            },
            {
              "type": "sand",
              "x": 224,
              "y": 384,
              "width": 80,
              "height": 8
            },
            {
              "type": "water",
              "x": 304,
              "y": 384,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 360,
              "y": 384,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 416,
              "y": 384,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 472,
              "y": 384,
              "width": 104,
              "height": 8
            },
            {
              "type": "water",
              "x": 576,
              "y": 384,
              "width": 104,
              "height": 8
            },
            {
              "type": "sand",
              "x": 224,
              "y": 392,
              "width": 72,
              "height": 8
            },
            {
              "type": "water",
              "x": 296,
              "y": 392,
              "width": 72,
              "height": 8
            },
            {
              "type": "sand",
              "x": 368,
              "y": 392,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 392,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 464,
              "y": 392,
              "width": 96,
              "height": 8
            },
            {
              "type": "water",
              "x": 560,
              "y": 392,
              "width": 120,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 400,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 232,
              "y": 400,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 296,
              "y": 400,
              "width": 80,
              "height": 8
            },
            {
              "type": "sand",
              "x": 376,
              "y": 400,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 432,
              "y": 400,
              "width": 8,
              "height": 8
            },
            {
              "type": "sand",
              "x": 440,
              "y": 400,
              "width": 88,
              "height": 8
            },
            {
              "type": "water",
              "x": 528,
              "y": 400,
              "width": 152,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 408,
              "width": 88,
              "height": 8
            },
            {
              "type": "sand",
              "x": 240,
              "y": 408,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 304,
              "y": 408,
              "width": 72,
              "height": 8
            },
            {
              "type": "sand",
              "x": 376,
              "y": 408,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 504,
              "y": 408,
              "width": 176,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 416,
              "width": 96,
              "height": 8
            },
            {
              "type": "sand",
              "x": 248,
              "y": 416,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 312,
              "y": 416,
              "width": 56,
              "height": 8
            },
            {
              "type": "sand",
              "x": 368,
              "y": 416,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 496,
              "y": 416,
              "width": 184,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 424,
              "width": 104,
              "height": 8
            },
            {
              "type": "sand",
              "x": 256,
              "y": 424,
              "width": 64,
              "height": 8
            },
            {
              "type": "water",
              "x": 320,
              "y": 424,
              "width": 40,
              "height": 8
            },
            {
              "type": "sand",
              "x": 360,
              "y": 424,
              "width": 120,
              "height": 8
            },
            {
              "type": "water",
              "x": 480,
              "y": 424,
              "width": 200,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 432,
              "width": 120,
              "height": 8
            },
            {
              "type": "sand",
              "x": 272,
              "y": 432,
              "width": 200,
              "height": 8
            },
            {
              "type": "water",
              "x": 472,
              "y": 432,
              "width": 208,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 440,
              "width": 128,
              "height": 8
            },
            {
              "type": "sand",
              "x": 280,
              "y": 440,
              "width": 176,
              "height": 8
            },
            {
              "type": "water",
              "x": 456,
              "y": 440,
              "width": 224,
              "height": 16
            },
            {
              "type": "water",
              "x": 152,
              "y": 448,
              "width": 136,
              "height": 8
            },
            {
              "type": "sand",
              "x": 288,
              "y": 448,
              "width": 168,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 456,
              "width": 144,
              "height": 8
            },
            {
              "type": "sand",
              "x": 296,
              "y": 456,
              "width": 128,
              "height": 8
            },
            {
              "type": "water",
              "x": 424,
              "y": 456,
              "width": 256,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 464,
              "width": 152,
              "height": 8
            },
            {
              "type": "sand",
              "x": 304,
              "y": 464,
              "width": 56,
              "height": 8
            },
            {
              "type": "water",
              "x": 360,
              "y": 464,
              "width": 320,
              "height": 8
            },
            {
              "type": "water",
              "x": 152,
              "y": 472,
              "width": 528,
              "height": 32
            }
          ]
        },
        "collision": {
          "waterRects": []
        },
        "npcs": [
          {
            "id": "crabBeach:npc:beachGirl",
            "type": "beachGirl",
            "name": "Sunny",
            "x": 578,
            "y": 324,
            "interactionRadius": 28
          }
        ]
      },
      "waterfallGrove": {
        "name": "Waterfall Grove",
        "dimensions": {
          "width": 640,
          "height": 520
        },
        "playerSpawns": [
          {
            "id": "southEntrance",
            "x": 319,
            "y": 465
          }
        ],
        "portals": [
          {
            "id": "waterfallGrove:portal:south",
            "x": 292,
            "y": 500,
            "width": 56,
            "height": 12,
            "targetMapId": "prototypeIslandWest",
            "targetSpawnId": "waterfallTrail"
          }
        ],
        "environment": {
          "trees": [
            {
              "id": "waterfallGrove:tree:1",
              "x": 80,
              "y": 84,
              "phase": 0.21,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:2",
              "x": 108,
              "y": 84,
              "phase": 0.78,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:3",
              "x": 136,
              "y": 84,
              "phase": 1.35,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:4",
              "x": 164,
              "y": 84,
              "phase": 1.92,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:5",
              "x": 192,
              "y": 84,
              "phase": 2.49,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:6",
              "x": 220,
              "y": 84,
              "phase": 3.06,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:7",
              "x": 248,
              "y": 84,
              "phase": 3.63,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:8",
              "x": 392,
              "y": 84,
              "phase": 4.2,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:9",
              "x": 420,
              "y": 84,
              "phase": 4.77,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:10",
              "x": 448,
              "y": 84,
              "phase": 5.34,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:11",
              "x": 476,
              "y": 84,
              "phase": 5.91,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:12",
              "x": 504,
              "y": 84,
              "phase": 6.48,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:13",
              "x": 532,
              "y": 84,
              "phase": 7.05,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:14",
              "x": 560,
              "y": 84,
              "phase": 7.62,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:15",
              "x": 92,
              "y": 110,
              "phase": 8.19,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:16",
              "x": 120,
              "y": 110,
              "phase": 8.76,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:17",
              "x": 148,
              "y": 110,
              "phase": 9.33,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:18",
              "x": 176,
              "y": 110,
              "phase": 9.9,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:19",
              "x": 204,
              "y": 110,
              "phase": 10.47,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:20",
              "x": 232,
              "y": 110,
              "phase": 11.04,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:21",
              "x": 404,
              "y": 110,
              "phase": 11.61,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:22",
              "x": 432,
              "y": 110,
              "phase": 12.18,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:23",
              "x": 460,
              "y": 110,
              "phase": 12.75,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:24",
              "x": 488,
              "y": 110,
              "phase": 13.32,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:25",
              "x": 516,
              "y": 110,
              "phase": 13.89,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:26",
              "x": 544,
              "y": 110,
              "phase": 14.46,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:27",
              "x": 92,
              "y": 432,
              "phase": 15.03,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:28",
              "x": 120,
              "y": 432,
              "phase": 15.6,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:29",
              "x": 148,
              "y": 432,
              "phase": 16.17,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:30",
              "x": 176,
              "y": 432,
              "phase": 16.74,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:31",
              "x": 204,
              "y": 432,
              "phase": 17.31,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:32",
              "x": 232,
              "y": 432,
              "phase": 17.88,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:33",
              "x": 260,
              "y": 432,
              "phase": 18.45,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:34",
              "x": 372,
              "y": 432,
              "phase": 19.02,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:35",
              "x": 400,
              "y": 432,
              "phase": 19.59,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:36",
              "x": 428,
              "y": 432,
              "phase": 20.16,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:37",
              "x": 456,
              "y": 432,
              "phase": 20.73,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:38",
              "x": 484,
              "y": 432,
              "phase": 21.3,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:39",
              "x": 512,
              "y": 432,
              "phase": 21.87,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:40",
              "x": 540,
              "y": 432,
              "phase": 22.44,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:41",
              "x": 80,
              "y": 456,
              "phase": 23.01,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:42",
              "x": 108,
              "y": 456,
              "phase": 23.58,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:43",
              "x": 136,
              "y": 456,
              "phase": 24.15,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:44",
              "x": 164,
              "y": 456,
              "phase": 24.72,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:45",
              "x": 192,
              "y": 456,
              "phase": 25.29,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:46",
              "x": 220,
              "y": 456,
              "phase": 25.86,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:47",
              "x": 248,
              "y": 456,
              "phase": 26.43,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:48",
              "x": 388,
              "y": 456,
              "phase": 27,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:49",
              "x": 416,
              "y": 456,
              "phase": 27.57,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:50",
              "x": 444,
              "y": 456,
              "phase": 28.14,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:51",
              "x": 472,
              "y": 456,
              "phase": 28.71,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:52",
              "x": 500,
              "y": 456,
              "phase": 29.28,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:53",
              "x": 528,
              "y": 456,
              "phase": 29.85,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:54",
              "x": 556,
              "y": 456,
              "phase": 30.42,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:55",
              "x": 80,
              "y": 132,
              "phase": 30.99,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:56",
              "x": 104,
              "y": 144,
              "phase": 31.56,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:57",
              "x": 536,
              "y": 144,
              "phase": 32.13,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:58",
              "x": 560,
              "y": 132,
              "phase": 32.7,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:59",
              "x": 80,
              "y": 160,
              "phase": 33.27,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:60",
              "x": 104,
              "y": 172,
              "phase": 33.84,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:61",
              "x": 536,
              "y": 172,
              "phase": 34.41,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:62",
              "x": 560,
              "y": 160,
              "phase": 34.98,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:63",
              "x": 80,
              "y": 188,
              "phase": 35.55,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:64",
              "x": 104,
              "y": 200,
              "phase": 36.12,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:65",
              "x": 536,
              "y": 200,
              "phase": 36.69,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:66",
              "x": 560,
              "y": 188,
              "phase": 37.26,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:67",
              "x": 80,
              "y": 216,
              "phase": 37.83,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:68",
              "x": 104,
              "y": 228,
              "phase": 38.4,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:69",
              "x": 536,
              "y": 228,
              "phase": 38.97,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:70",
              "x": 560,
              "y": 216,
              "phase": 39.54,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:71",
              "x": 80,
              "y": 244,
              "phase": 40.11,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:72",
              "x": 104,
              "y": 256,
              "phase": 40.68,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:73",
              "x": 536,
              "y": 256,
              "phase": 41.25,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:74",
              "x": 560,
              "y": 244,
              "phase": 41.82,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:75",
              "x": 80,
              "y": 272,
              "phase": 42.39,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:76",
              "x": 104,
              "y": 284,
              "phase": 42.96,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:77",
              "x": 536,
              "y": 284,
              "phase": 43.53,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:78",
              "x": 560,
              "y": 272,
              "phase": 44.1,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:79",
              "x": 80,
              "y": 300,
              "phase": 44.67,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:80",
              "x": 104,
              "y": 312,
              "phase": 45.24,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:81",
              "x": 536,
              "y": 312,
              "phase": 45.81,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:82",
              "x": 560,
              "y": 300,
              "phase": 46.38,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:83",
              "x": 80,
              "y": 328,
              "phase": 46.95,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:84",
              "x": 104,
              "y": 340,
              "phase": 47.52,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:85",
              "x": 536,
              "y": 340,
              "phase": 48.09,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:86",
              "x": 560,
              "y": 328,
              "phase": 48.66,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:87",
              "x": 80,
              "y": 356,
              "phase": 49.23,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:88",
              "x": 104,
              "y": 368,
              "phase": 49.8,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:89",
              "x": 536,
              "y": 368,
              "phase": 50.37,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:90",
              "x": 560,
              "y": 356,
              "phase": 50.94,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:91",
              "x": 80,
              "y": 384,
              "phase": 51.51,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:92",
              "x": 104,
              "y": 396,
              "phase": 52.08,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:93",
              "x": 536,
              "y": 396,
              "phase": 52.65,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:94",
              "x": 560,
              "y": 384,
              "phase": 53.22,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:95",
              "x": 80,
              "y": 412,
              "phase": 53.79,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:96",
              "x": 104,
              "y": 424,
              "phase": 54.36,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:97",
              "x": 536,
              "y": 424,
              "phase": 54.93,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:98",
              "x": 560,
              "y": 412,
              "phase": 55.5,
              "fireImmune": true,
              "nonInteractive": true,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:99",
              "x": 132,
              "y": 164,
              "phase": 56.07,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:100",
              "x": 158,
              "y": 188,
              "phase": 56.64,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:101",
              "x": 126,
              "y": 242,
              "phase": 57.21,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:102",
              "x": 154,
              "y": 276,
              "phase": 57.78,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:103",
              "x": 118,
              "y": 334,
              "phase": 58.35,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:104",
              "x": 150,
              "y": 370,
              "phase": 58.92,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:105",
              "x": 190,
              "y": 404,
              "phase": 59.49,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:106",
              "x": 230,
              "y": 430,
              "phase": 60.06,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:107",
              "x": 508,
              "y": 166,
              "phase": 60.63,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:108",
              "x": 482,
              "y": 190,
              "phase": 61.2,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:109",
              "x": 516,
              "y": 244,
              "phase": 61.77,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:110",
              "x": 486,
              "y": 282,
              "phase": 62.34,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:111",
              "x": 522,
              "y": 336,
              "phase": 62.91,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:112",
              "x": 488,
              "y": 374,
              "phase": 63.48,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:113",
              "x": 446,
              "y": 414,
              "phase": 64.05,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:114",
              "x": 410,
              "y": 438,
              "phase": 64.62,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            },
            {
              "id": "waterfallGrove:tree:115",
              "x": 198,
              "y": 146,
              "phase": 65.19,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 0
            },
            {
              "id": "waterfallGrove:tree:116",
              "x": 442,
              "y": 146,
              "phase": 65.76,
              "fireImmune": false,
              "nonInteractive": false,
              "canopyVariant": 1
            }
          ],
          "tallGrass": [
            {
              "id": "waterfallGrove:grass:1",
              "x": 178,
              "y": 232,
              "phase": 0.35,
              "width": 11,
              "flowerType": "yellow"
            },
            {
              "id": "waterfallGrove:grass:2",
              "x": 196,
              "y": 252,
              "phase": 0.84,
              "width": 12,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:3",
              "x": 154,
              "y": 302,
              "phase": 1.33,
              "width": 13,
              "flowerType": "white"
            },
            {
              "id": "waterfallGrove:grass:4",
              "x": 188,
              "y": 326,
              "phase": 1.82,
              "width": 14,
              "flowerType": "blue"
            },
            {
              "id": "waterfallGrove:grass:5",
              "x": 216,
              "y": 350,
              "phase": 2.31,
              "width": 15,
              "flowerType": "yellow"
            },
            {
              "id": "waterfallGrove:grass:6",
              "x": 176,
              "y": 390,
              "phase": 2.8,
              "width": 11,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:7",
              "x": 248,
              "y": 330,
              "phase": 3.29,
              "width": 12,
              "flowerType": "white"
            },
            {
              "id": "waterfallGrove:grass:8",
              "x": 260,
              "y": 372,
              "phase": 3.78,
              "width": 13,
              "flowerType": "blue"
            },
            {
              "id": "waterfallGrove:grass:9",
              "x": 236,
              "y": 410,
              "phase": 4.27,
              "width": 14,
              "flowerType": "yellow"
            },
            {
              "id": "waterfallGrove:grass:10",
              "x": 462,
              "y": 232,
              "phase": 4.76,
              "width": 15,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:11",
              "x": 444,
              "y": 258,
              "phase": 5.25,
              "width": 11,
              "flowerType": "white"
            },
            {
              "id": "waterfallGrove:grass:12",
              "x": 480,
              "y": 310,
              "phase": 5.74,
              "width": 12,
              "flowerType": "blue"
            },
            {
              "id": "waterfallGrove:grass:13",
              "x": 438,
              "y": 338,
              "phase": 6.23,
              "width": 13,
              "flowerType": "yellow"
            },
            {
              "id": "waterfallGrove:grass:14",
              "x": 466,
              "y": 366,
              "phase": 6.72,
              "width": 14,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:15",
              "x": 408,
              "y": 386,
              "phase": 7.21,
              "width": 15,
              "flowerType": "white"
            },
            {
              "id": "waterfallGrove:grass:16",
              "x": 394,
              "y": 426,
              "phase": 7.7,
              "width": 11,
              "flowerType": "blue"
            },
            {
              "id": "waterfallGrove:grass:17",
              "x": 284,
              "y": 344,
              "phase": 8.19,
              "width": 12,
              "flowerType": "yellow"
            },
            {
              "id": "waterfallGrove:grass:18",
              "x": 356,
              "y": 354,
              "phase": 8.68,
              "width": 13,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:19",
              "x": 278,
              "y": 398,
              "phase": 9.17,
              "width": 14,
              "flowerType": "white"
            },
            {
              "id": "waterfallGrove:grass:20",
              "x": 366,
              "y": 404,
              "phase": 9.66,
              "width": 15,
              "flowerType": "blue"
            },
            {
              "id": "waterfallGrove:grass:21",
              "x": 206,
              "y": 286,
              "phase": 10.15,
              "width": 11,
              "flowerType": null
            },
            {
              "id": "waterfallGrove:grass:22",
              "x": 426,
              "y": 292,
              "phase": 10.64,
              "width": 12,
              "flowerType": null
            },
            {
              "id": "waterfallGrove:grass:23",
              "x": 260,
              "y": 246,
              "phase": 11.13,
              "width": 13,
              "flowerType": "pink"
            },
            {
              "id": "waterfallGrove:grass:24",
              "x": 380,
              "y": 250,
              "phase": 11.62,
              "width": 14,
              "flowerType": "yellow"
            }
          ],
          "rocks": [
            {
              "id": "waterfallGrove:rock:1",
              "x": 206,
              "y": 214,
              "variant": "grass"
            },
            {
              "id": "waterfallGrove:rock:2",
              "x": 434,
              "y": 218,
              "variant": "grass"
            },
            {
              "id": "waterfallGrove:rock:3",
              "x": 226,
              "y": 294,
              "variant": "plain"
            },
            {
              "id": "waterfallGrove:rock:4",
              "x": 414,
              "y": 296,
              "variant": "plain"
            }
          ],
          "sceneryRocks": [
            {
              "id": "waterfallGrove:sceneryRock:1",
              "x": 184,
              "y": 196,
              "collision": {
                "width": 12,
                "height": 7
              }
            },
            {
              "id": "waterfallGrove:sceneryRock:2",
              "x": 456,
              "y": 198,
              "collision": {
                "width": 12,
                "height": 7
              }
            },
            {
              "id": "waterfallGrove:sceneryRock:3",
              "x": 246,
              "y": 286,
              "collision": {
                "width": 10,
                "height": 6
              }
            },
            {
              "id": "waterfallGrove:sceneryRock:4",
              "x": 394,
              "y": 286,
              "collision": {
                "width": 10,
                "height": 6
              }
            }
          ],
          "harvestFlowers": [
            {
              "id": "waterfallGrove:flower:1",
              "x": 164,
              "y": 214,
              "phase": 0.18,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:2",
              "x": 190,
              "y": 274,
              "phase": 0.81,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:3",
              "x": 146,
              "y": 352,
              "phase": 1.44,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:4",
              "x": 212,
              "y": 382,
              "phase": 2.07,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:5",
              "x": 250,
              "y": 308,
              "phase": 2.7,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:6",
              "x": 270,
              "y": 430,
              "phase": 3.33,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:7",
              "x": 476,
              "y": 216,
              "phase": 3.96,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:8",
              "x": 452,
              "y": 280,
              "phase": 4.59,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:9",
              "x": 494,
              "y": 346,
              "phase": 5.22,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:10",
              "x": 430,
              "y": 366,
              "phase": 5.85,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:11",
              "x": 392,
              "y": 444,
              "phase": 6.48,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:12",
              "x": 370,
              "y": 322,
              "phase": 7.11,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:13",
              "x": 226,
              "y": 334,
              "phase": 7.74,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:14",
              "x": 416,
              "y": 238,
              "phase": 8.37,
              "type": "blue"
            },
            {
              "id": "waterfallGrove:flower:15",
              "x": 198,
              "y": 414,
              "phase": 9,
              "type": "white"
            },
            {
              "id": "waterfallGrove:flower:16",
              "x": 458,
              "y": 404,
              "phase": 9.63,
              "type": "blue"
            }
          ],
          "houses": []
        },
        "enemySpawns": [],
        "npcs": [
          {
            "id": "waterfallGrove:npc:greenWitch",
            "type": "greenWitch",
            "name": "Myrtle",
            "x": 173,
            "y": 303,
            "interactionRadius": 24
          }
        ],
        "landmarks": {
          "waterfall": {
            "x": 320,
            "topY": 76,
            "baseY": 218,
            "width": 88,
            "cliffLeft": 160,
            "cliffRight": 480,
            "pool": {
              "x": 224,
              "y": 200,
              "width": 192,
              "height": 104
            }
          },
          "lightBeams": [
            {
              "x": 230,
              "y": 58,
              "width": 58,
              "height": 240,
              "lean": 42,
              "alpha": 0.09
            },
            {
              "x": 340,
              "y": 48,
              "width": 74,
              "height": 270,
              "lean": 24,
              "alpha": 0.12
            },
            {
              "x": 430,
              "y": 70,
              "width": 42,
              "height": 210,
              "lean": -18,
              "alpha": 0.07
            }
          ]
        },
        "terrain": {
          "cellSize": 8,
          "defaultType": "void",
          "regions": [
            {
              "type": "grass",
              "x": 64,
              "y": 64,
              "width": 96,
              "height": 136
            },
            {
              "type": "grass",
              "x": 272,
              "y": 64,
              "width": 96,
              "height": 16
            },
            {
              "type": "grass",
              "x": 480,
              "y": 64,
              "width": 96,
              "height": 136
            },
            {
              "type": "water",
              "x": 272,
              "y": 80,
              "width": 96,
              "height": 120
            },
            {
              "type": "grass",
              "x": 64,
              "y": 200,
              "width": 168,
              "height": 16
            },
            {
              "type": "water",
              "x": 232,
              "y": 200,
              "width": 176,
              "height": 16
            },
            {
              "type": "grass",
              "x": 408,
              "y": 200,
              "width": 168,
              "height": 16
            },
            {
              "type": "grass",
              "x": 64,
              "y": 216,
              "width": 160,
              "height": 56
            },
            {
              "type": "water",
              "x": 224,
              "y": 216,
              "width": 192,
              "height": 56
            },
            {
              "type": "grass",
              "x": 416,
              "y": 216,
              "width": 160,
              "height": 56
            },
            {
              "type": "grass",
              "x": 64,
              "y": 272,
              "width": 168,
              "height": 16
            },
            {
              "type": "water",
              "x": 232,
              "y": 272,
              "width": 176,
              "height": 16
            },
            {
              "type": "grass",
              "x": 408,
              "y": 272,
              "width": 168,
              "height": 16
            },
            {
              "type": "grass",
              "x": 64,
              "y": 288,
              "width": 184,
              "height": 16
            },
            {
              "type": "water",
              "x": 248,
              "y": 288,
              "width": 144,
              "height": 16
            },
            {
              "type": "grass",
              "x": 392,
              "y": 288,
              "width": 184,
              "height": 16
            },
            {
              "type": "grass",
              "x": 64,
              "y": 304,
              "width": 224,
              "height": 8
            },
            {
              "type": "dirt",
              "x": 288,
              "y": 304,
              "width": 64,
              "height": 8
            },
            {
              "type": "grass",
              "x": 352,
              "y": 304,
              "width": 224,
              "height": 8
            },
            {
              "type": "grass",
              "x": 64,
              "y": 312,
              "width": 240,
              "height": 152
            },
            {
              "type": "dirt",
              "x": 304,
              "y": 312,
              "width": 32,
              "height": 200
            },
            {
              "type": "grass",
              "x": 336,
              "y": 312,
              "width": 240,
              "height": 152
            }
          ]
        },
        "collision": {
          "waterRects": []
        }
      }
    },
    "defaultPlayerLoad": {
      "mapId": "prototypeIsland",
      "spawnId": "center"
    }
  });
});
